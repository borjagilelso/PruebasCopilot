﻿using MontesPatrimoniales.Bll.Interfaces.Gestion.Mantenimientos;
using MontesPatrimoniales.Dal.Interfaces.Gestion.Mantenimientos;
using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using MontesPatrimoniales.Entities.Utils;
using MontesPatrimoniales.GlobalResources;
using Ssid.Arquitectura.Infrastructure.Exceptions.Interfaces;
using Ssid.Arquitectura.Infrastructure.Logging.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace MontesPatrimoniales.Bll.Gestion.Mantenimientos
{
    public class MangasService : IMangasService
    {
        private readonly IMangasCrudRepository _repository;
        private readonly IExceptionManager _exceptionManager;

        public MangasService(IMangasCrudRepository repository, IExceptionManager exceptionManager)
        {
            _repository = repository;
            _exceptionManager = exceptionManager;
        }

        public Result<int> AltaManga(Manga manga)
        {

            try
            {
                bool insertado = _repository.AltaManga(manga);
                if (!insertado)
                {
                    return Results.Fail<int>(Resource.CeroRegistrosAfectadosInsertandoBalsas);
                }
                return Results.Ok(manga.IdManga);
            }
            catch (Exception ex)
            {
                _exceptionManager.HandleException(ex, Layer.Bll);
                return Results.Fail<int>(Resource.ExcepcionInsertandoMangas);
            }
        }

        public Result<Manga> GetMangaById(int idManga)
        {
            try
            {
                var balsa = _repository.GetMangaById(idManga);
                if (balsa == null)
                {
                    return Results.Fail<Manga>(String.Format(Resource.NoEncontradaMangaPorId, idManga));
                }
                return Results.Ok(balsa);
            }
            catch (Exception ex)
            {
                _exceptionManager.HandleException(ex, Layer.Bll);
                return Results.Fail<Manga>(Resource.ExcepcionObteniendoManga);
            }
        }

        public Result<bool> ModificarManga(Manga manga)
        {
            try
            {
                bool modificado = _repository.ModificarManga(manga);
                if (!modificado)
                {
                    return Results.Ok(false);
                }
                return Results.Ok(true);
            }
            catch (Exception ex)
            {
                _exceptionManager.HandleException(ex, Layer.Bll);
                return Results.Fail<bool>(Resource.ExcepcionModificandoMangas);
            }
        }

        public Result EliminarManga(int idManga)
        {
            try
            {
                bool eliminado = _repository.EliminarManga(idManga);
                if (!eliminado)
                {
                    return Results.Fail(Resource.CeroRegistrosAfectadosEliminandoArchivos);
                }
                return Results.Ok();
            }
            catch (SqlException ex) when (ex.Number == Constants.CodigErrorConstraintBDD)
            {
                return Results.Fail(Resource.MsgNoSePuedeEliminarRegistroEnUso);
            }
            catch (Exception ex)
            {
                _exceptionManager.HandleException(ex, Layer.Bll);
                return Results.Fail(Resource.ExcepcionEliminandoManga);
            }
        }

        public Result<List<Manga>> GetMangas(int? localidad, string claveFiltro, string parajeFiltro)
        {
            try
            {
                var mangas = _repository.GetMangas(localidad, claveFiltro, parajeFiltro);
                return Results.Ok(mangas);
            }
            catch (Exception ex)
            {
                _exceptionManager.HandleException(ex, Layer.Bll);
                return Results.Fail<List<Manga>>(Resource.ExcepcionObteniendoMangas);
            }
        }
    }
}
