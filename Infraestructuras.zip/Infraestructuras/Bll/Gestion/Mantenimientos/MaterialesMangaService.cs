﻿using MontesPatrimoniales.Bll.Interfaces;
using MontesPatrimoniales.Dal.Interfaces.Gestion.Mantenimientos;
using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using MontesPatrimoniales.Entities.Utils;
using MontesPatrimoniales.GlobalResources;
using Ssid.Arquitectura.Infrastructure.Exceptions.Interfaces;
using Ssid.Arquitectura.Infrastructure.Logging.Entities;
using System;
using System.Collections.Generic;

namespace MontesPatrimoniales.Bll
{
    public class MaterialesMangaService : IMaterialesMangaService
    {
        private readonly IMaterialesMangaCrudRepository _repository;
        private readonly IExceptionManager _exceptionManager;

        public MaterialesMangaService(IMaterialesMangaCrudRepository repository, IExceptionManager exceptionManager)
        {
            _repository = repository;
            _exceptionManager = exceptionManager;
        }

        public Result<List<MaterialManga>> GetMaterialesManga()
        {
            try
            {
                var elementos = _repository.GetMaterialesManga();
                return Results.Ok(elementos);
            }
            catch (Exception ex)
            {
                _exceptionManager.HandleException(ex, Layer.Bll);
                return Results.Fail<List<MaterialManga>>(Resource.ExcepcionObteniendoMaterialManga);
            }
        }
    }
}
