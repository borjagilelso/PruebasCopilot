﻿using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using System.Collections.Generic;

namespace MontesPatrimoniales.Bll.Interfaces.Gestion.Mantenimientos
{
    public interface IMangasService
    {
        Result<int> AltaManga(Manga manga);
        Result<Manga> GetMangaById(int idManga);
        Result<bool> ModificarManga(Manga manga);
        Result EliminarManga(int idManga);
        Result<List<Manga>> GetMangas(int? localidad, string claveFiltro, string parajeFiltro);
    }
}
