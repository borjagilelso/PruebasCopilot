﻿using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using System.Collections.Generic;

namespace MontesPatrimoniales.Bll.Interfaces
{
    public interface IMaterialesMangaService
    {
        Result<List<MaterialManga>> GetMaterialesManga();
    }
}
