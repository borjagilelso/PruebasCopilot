﻿using System;

namespace MontesPatrimoniales.Entities.Gestion.Mantenimientos
{
    public class Manga
    {
        public int IdManga{ get; set; }
        public int IdInfraestructura { get; set; }
        public int IdLocalidad { get; set; }
        public string Codigo { get; set; }
        public string Paraje { get; set; }
        public int UtmX { get; set; }
        public int UtmY { get; set; }
        public int Anio { get; set; }
        public decimal? Dimension { get; set; }
        public int? IdMaterialCierre{ get; set; }
        public int? IdMaterialPortillo { get; set; }
        public string NumeroPortillos { get; set; }
        public bool? AtrapaderaGanadoMayor { get; set; }
        public bool? AtrapaderaGanadoMenor { get; set; }
        public bool? FuncionamientoCorrectoPortillos { get; set; }
        public bool? SoleraPasillo { get; set; }
        public decimal? DimensionSolera { get; set; }
        public int? IdEstadoConservacion { get; set; }
        public int IdEstadoAcceso{ get; set; }
        public int IdEntorno { get; set; }
        public string Observaciones { get; set; }
        public DateTime FechaUltimaInspeccion { get; set; }

        public string NombreLocalidad { get; set; }
        public string Utm { get; set; }
    }
}
