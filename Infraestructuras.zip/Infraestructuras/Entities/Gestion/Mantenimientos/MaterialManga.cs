﻿namespace MontesPatrimoniales.Entities.Gestion.Mantenimientos
{
    public class MaterialManga
    {
        public int IdMaterial { get; set; }
        public string Nombre { get; set; }
        public int Baja { get; set; }
    }
}

