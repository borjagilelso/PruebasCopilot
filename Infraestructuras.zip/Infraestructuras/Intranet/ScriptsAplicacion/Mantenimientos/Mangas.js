
var url = window.location.pathname.split('/')[1];


function EndClean(url) {
    PNotify.success({
        text:"La manga se ha guardado correctamente",
        // necesario para que muestre html enriquecido en la notificaci�n
        textTrusted: true
    });
    window.location.href = url;
}

function Ok() {

    PNotify.success({
        text: "La manga se ha modificado correctamente",
        // necesario para que muestre html enriquecido en la notificaci�n
        textTrusted: true
    });

}



$(document).ready(function () {
    if (typeof window.Aplicacion == "undefined") {
        window.Aplicacion = {};
    }

    if (typeof window.Aplicacion.Mantenimientos == "undefined") {
        window.Aplicacion.Mantenimientos = {};
    }

    if (typeof window.Aplicacion.Mantenimientos.Mangas == "undefined") {
        window.Aplicacion.Mantenimientos.Mangas = {};
    }
});


$(document).ready(function () {

    window.Aplicacion.Mantenimientos.Mangas = {

        init: function (config) {
            this.idLocalidad = config.idLocalidad;
            /*this.selectElementoJson = config.selectElementoJson;*/
            this.idManga = config.idManga;
            this.initEventos();
        },

        initEventos: function (grid) {
            var mangas = this;

            var idLocalidad = mangas.idLocalidad;
            $("#SelectedLocalidad").val(idLocalidad).change();
        },
    };
});


$(document).ready(function () {

    window.Aplicacion.Mantenimientos.MangasGrid = {

        init: function (config) {
            this.idLocalidad = config.idLocalidad;
            this.idManga = config.idManga;
            this.urlInsercion = config.urlInsercion;
            this.urlEliminacion = config.urlEliminacion;
            this.idGrid = config.idGrid;
            this.idForm = config.idForm;
            this.urlEdicion = config.urlEdicion;
            this.initEventos();
        },

        idGrid: "",
        idForm: "",
        urlEliminacion: "",
        urlEdicion: "",
        urlInsercion: "",
        initEventos: function (grid) {
            var datosMangas = this;
            var grid = window.Aplicacion.Plugins.GridScripts.obtenerObjeto("#" + datosMangas.idGrid)[0];


            $(grid).on("mostrarModalOutline",
                function (event, $grid, primaryKey, $row, datosRow) { // }, $modal) {
                    var rutaActual = window.location.href.split("Manga");
                    var ruta = rutaActual[0] + "Manga" + "/FichaManga?idManga=" + datosRow.IdManga;
                    location.href = ruta;
                });

            $(grid).on("borrar", function (event, $grid, primaryKey, $row, datosRow) {
                return new Promise(function (resolve) {
                    var idManga = datosRow.IdManga;
   
                    $.ajax({
                        type: "POST",
                        url: datosMangas.urlEliminacion,
                        global: true,
                        data: {
                            "idManga": idManga
                        },
                        success: function (data) {

                            PNotify.success({
                                text: data.responseText,
                                // necesario para que muestre html enriquecido en la notificaci�n
                                textTrusted: true
                            });
                            resolve(true);
                        },
                        error: function (data) {
                            $.desbloquearPantalla();
                            alert(data.responseJSON);
                            resolve(false);
                        }
                    });
                });
            });
        },
    };
});