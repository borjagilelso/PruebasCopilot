﻿using AutoMapper;
using MontesPatrimoniales.Bll.Interfaces;
using MontesPatrimoniales.Bll.Interfaces.Gestion.Mantenimientos;
using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Filtros;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Chabolas;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Infraestructuras;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.Ssid.Utilities.Attributes;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.Ssid.Utilities.Extensions;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.Ssid.Utilities.Utils;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.Ssid.ViewModels.Mensajes;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.Ssid.Utilities.Enums;
using MontesPatrimoniales.GlobalResources;
using Ssid.Arquitectura.Infrastructure.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Mangas;

namespace MontesPatrimoniales.Intranet.Controllers
{
    public class MangaController : AtekaController
    {
        private readonly ILocalidadesService _localidadesService;
        private readonly IMapper _mapper;
        private readonly ISubidaBajadaFicherosService _subidaBajadaFicherosService;
        private readonly ITiposAccesoService _tiposAccesoService;
        private readonly IInfraestructurasService _infraestructurasService;
        private readonly IEstadosService _estadosService;
        private readonly IEntornosService _entornosService;
        private readonly IIncidenciasInfraestructuraService _incidenciasInfraestructuraService;
        private readonly IMaterialesMangaService _materialesMangaService;
        private readonly IMangasService _mangasService;

        public static List<SelectListItem> TiposIncidencia { get; set; }

        public MangaController(ILocalidadesService localidadesService, IMapper mapper, IMangasService mangasService,
                                    ISubidaBajadaFicherosService subidaBajadaFicherosService, ITiposAccesoService tiposAccesoService,
                                    IInfraestructurasService infraestructurasService, IEstadosService estadosService, IEntornosService entornosService,
                                    IIncidenciasInfraestructuraService incidenciasInfraestructuraService, 
                                    IMaterialesMangaService materialesMangaService)
        {
            _localidadesService = localidadesService;
            _mapper = mapper;
            _mangasService = mangasService;
            _subidaBajadaFicherosService = subidaBajadaFicherosService;
            _tiposAccesoService = tiposAccesoService;
            _infraestructurasService = infraestructurasService;
            _estadosService = estadosService;
            _entornosService = entornosService;
            _incidenciasInfraestructuraService = incidenciasInfraestructuraService;
            _materialesMangaService = materialesMangaService;
        }

        public ActionResult Manga()
        {
            if (UserManager.TieneRol(Filtros.Administrador) || UserManager.TieneRol(Filtros.Consultor) || UserManager.EsUsuarioInternet)
            {
                var viewModel = new MangasViewModel
                {
                    Localidades = _localidadesService.GetLocalidades().GetValue()
                };

                return View("Manga", viewModel);
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }
         
        [HttpGet]
        public ActionResult AltaManga()
        {
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                 var viewModel = new MangasViewModelEdit();

                viewModel.Localidades = _localidadesService.GetLocalidades().GetValue();
                viewModel.Infraestructuras = _infraestructurasService.GetInfraestructuras().GetValue();
                viewModel.SelectedInfraestructura = (int)InfraestructuraEnum.Manga;

                var materiales = _materialesMangaService.GetMaterialesManga().GetValue();
                viewModel.MaterialesCierre = materiales;
                viewModel.MaterialesPortillo = materiales;

                var estados = _estadosService.GetEstados().GetValue();
                viewModel.EstadosConservacion = estados;
                viewModel.EstadosAcceso= estados;

                viewModel.Entornos = _entornosService.GetEntornos().GetValue();
                
                return View("AltaManga", viewModel);
            }
            else
            {
                return RedirectToAction("Manga");
            }
        }

        [HttpGet]
        public ActionResult MapaManga()
        {
            var viewModel = new MangaMapaViewModel
            {
                Mangas = _mangasService.GetMangas(null, string.Empty, string.Empty).GetValue()
            };

            return View("MapaMangas", viewModel);
        }

        [HttpPost]
        public ActionResult GuardarManga(MangasViewModelEdit mangasViewModel)
        {
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                mangasViewModel.Localidades = _localidadesService.GetLocalidades().GetValue();
                var local = mangasViewModel.Localidades
                .FirstOrDefault(x => x.IdLocalidad == mangasViewModel.SelectedLocalidad);

                mangasViewModel.Infraestructuras = _infraestructurasService.GetInfraestructuras().GetValue();
                var infra = mangasViewModel.Infraestructuras
                 .FirstOrDefault(x => x.IdInfraestructura == mangasViewModel.SelectedInfraestructura);

                var manga = new Manga()
                {
                    IdInfraestructura = mangasViewModel.SelectedInfraestructura,
                    IdLocalidad = mangasViewModel.SelectedLocalidad,
                    Codigo = $"{local?.CodigoLocalidad}{infra?.Codigo}",
                    Paraje = mangasViewModel.Paraje,
                    UtmX = mangasViewModel.UtmX,
                    UtmY = mangasViewModel.UtmY,
                    Anio = mangasViewModel.Anio,
                    Dimension= mangasViewModel.Dimension,
                    IdMaterialCierre = mangasViewModel.SelectedMaterialCierre,
                    IdMaterialPortillo = mangasViewModel.SelectedMaterialPortillo,
                    NumeroPortillos = mangasViewModel.NumeroPortillos,
                    AtrapaderaGanadoMayor = mangasViewModel.AtrapaderaGanadoMayor,
                    AtrapaderaGanadoMenor= mangasViewModel.AtrapaderaGanadoMenor,
                    FuncionamientoCorrectoPortillos = mangasViewModel.FuncionamientoCorrectoPortillos,
                    SoleraPasillo = mangasViewModel.SoleraPasillo,
                    DimensionSolera = mangasViewModel.DimensionSolera,
                    IdEstadoConservacion = mangasViewModel.SelectedEstadoConservacion,
                    IdEstadoAcceso = mangasViewModel.SelectedEstadoAcceso,
                    IdEntorno = mangasViewModel.SelectedEntorno,
                    Observaciones = mangasViewModel.Observaciones ?? "",
                    FechaUltimaInspeccion = mangasViewModel.FechaUltimaInspeccion
                };

                var result = _mangasService.AltaManga(manga);

                var url = Url.Action("FichaManga", new { idManga = result.GetValue() }).ToString();
                return Content(url);

            }

            return RedirectToAction("Manga");
        }

        [HttpGet]
        public ActionResult FichaManga(int idManga)
        {
            var datosManga= _mangasService.GetMangaById(idManga).GetValue();
            var resultIncidenciasInfraestructura = _incidenciasInfraestructuraService.GetIncidenciasInfraestructuraByIdElemento(idManga, (int)InfraestructuraEnum.Manga);
            var tiposIncidencias = _incidenciasInfraestructuraService.GetIncidencias().GetValue();
            
            MangaController.TiposIncidencia = resultIncidenciasInfraestructura.Success
                      ? _mapper.Map<List<SelectListItem>>(tiposIncidencias)
                      : new List<SelectListItem>();

            var listaIncidencias = new List<IncidenciaInfraestructuraViewModel>();

            listaIncidencias = resultIncidenciasInfraestructura.Success
                                    ? resultIncidenciasInfraestructura.GetValue()
                                        .Select(x => new IncidenciaInfraestructuraViewModel
                                        {
                                            IdIncidenciaInfraestructura = x.IdIncidenciaInfraestructura,
                                            IdInfraestructura = x.IdInfraestructura,
                                            IdIncidencia = x.IdIncidencia,
                                            IdElemento = x.IdElemento,
                                            FechaIncidencia = x.FechaIncidencia,
                                            NombreTipoIncidencia = x.NombreTipoIncidencia,
                                            Archivos = new List<DocumentosIncidenciaInfraestructuraViewModel>()
                                        }).ToList()
                                    : new List<IncidenciaInfraestructuraViewModel>();
            
            var viewModel = new MangasViewModelEdit();
            viewModel.IdManga = idManga;
            viewModel.Infraestructuras = _infraestructurasService.GetInfraestructuras().GetValue();
            viewModel.SelectedInfraestructura = datosManga.IdInfraestructura;
            viewModel.IdInfraestructura = datosManga.IdInfraestructura;
            viewModel.Localidades = _localidadesService.GetLocalidades().GetValue();
            viewModel.IdLocalidad = datosManga.IdLocalidad;
            viewModel.Codigo = datosManga.Codigo;
            viewModel.Paraje = datosManga.Paraje;
            viewModel.UtmX = datosManga.UtmX;
            viewModel.UtmY = datosManga.UtmY;
            viewModel.Anio = datosManga.Anio;
            viewModel.Dimension = datosManga.Dimension;
            var materiales = _materialesMangaService.GetMaterialesManga().GetValue();
            viewModel.MaterialesCierre = materiales;
            viewModel.MaterialesPortillo = materiales;
            viewModel.IdMaterialCierre = datosManga.IdMaterialCierre;
            viewModel.SelectedMaterialCierre = datosManga.IdMaterialCierre;
            viewModel.IdMaterialPortillo = datosManga.IdMaterialPortillo;
            viewModel.SelectedMaterialPortillo = datosManga.IdMaterialPortillo;
            viewModel.NumeroPortillos = datosManga.NumeroPortillos;
            viewModel.AtrapaderaGanadoMayor = datosManga.AtrapaderaGanadoMayor ?? false;
            viewModel.AtrapaderaGanadoMenor = datosManga.AtrapaderaGanadoMenor ?? false;
            viewModel.FuncionamientoCorrectoPortillos = datosManga.FuncionamientoCorrectoPortillos?? false;
            viewModel.SoleraPasillo = datosManga.SoleraPasillo ?? false;
            viewModel.DimensionSolera = datosManga.DimensionSolera;
            var estados = _estadosService.GetEstados().GetValue();
            viewModel.EstadosAcceso = estados;
            viewModel.EstadosConservacion = estados;
            viewModel.IdEstadoAcceso = datosManga.IdEstadoAcceso;
            viewModel.IdEstadoConservacion = datosManga.IdEstadoConservacion;
            viewModel.SelectedEstadoAcceso = datosManga.IdEstadoAcceso;
            viewModel.SelectedEstadoConservacion = datosManga.IdEstadoConservacion;
            viewModel.Entornos = _entornosService.GetEntornos().GetValue();
            viewModel.IdEntorno = datosManga.IdEntorno;
            viewModel.SelectedEntorno = datosManga.IdEntorno;
            viewModel.Observaciones = datosManga.Observaciones;
            viewModel.FechaUltimaInspeccion = datosManga.FechaUltimaInspeccion;

            viewModel.Incidencias = listaIncidencias;
            
            return View("FichaManga", viewModel);
        }

        [HttpPost]
        [AjaxOnly]
        public JsonResult EliminarManga(int idElemento)
        {
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                var result = _mangasService.EliminarManga(idElemento);
                if (result.Failure)
                {
                    return JsonBadRequest(result.Message());
                }

                return JsonOk(new
                {
                    redirectUrl = Url.Action("Index", "Home"),
                    responseText = Resource.DatosEliminadosCorrectamente
                });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        [HttpPost]
        [AjaxOnly]
        public ActionResult InsertarIncidenciaInfraestructura(IncidenciaInfraestructuraViewModel viewModel)
        {
            viewModel.IdInfraestructura = (int)InfraestructuraEnum.Manga;
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                //var incidenciaInfraestructura = _mapper.Map<IncidenciaInfraestructura>(viewModel);

                IncidenciaInfraestructura incidenciaInfraestructura = new IncidenciaInfraestructura();
                // Asignamos los campos manualmente desde el ViewModel
                if (viewModel != null)
                {
                    incidenciaInfraestructura.IdInfraestructura = viewModel.IdInfraestructura;
                    incidenciaInfraestructura.IdIncidencia = viewModel.IdIncidencia;
                    incidenciaInfraestructura.IdElemento = viewModel.IdElemento;
                    incidenciaInfraestructura.FechaIncidencia = viewModel.FechaIncidencia;
                }

                var result = _incidenciasInfraestructuraService.InsertarIncidenciaInfraestructura(incidenciaInfraestructura);

                if (result.Failure)
                {
                    return JsonBadRequest(result.Message());
                }

                return JsonOk(new { responseText = Resource.DatosGuardadosCorrectamente, idIncidencia = result.GetValue() });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }


        }

        [HttpPost]
        [AjaxOnly]
        public JsonResult ModificarIncidenciaInfraestructura(IncidenciaInfraestructuraViewModel viewModel)
        {
            viewModel.IdInfraestructura = (int)InfraestructuraEnum.Manga;
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                //var incidenciaInfraestructura = _mapper.Map<IncidenciaInfraestructura>(viewModel);
                
                IncidenciaInfraestructura incidenciaInfraestructura = new IncidenciaInfraestructura();
                // Asignamos los campos manualmente desde el ViewModel
                if (viewModel != null)
                {
                    incidenciaInfraestructura.IdIncidenciaInfraestructura = viewModel.IdIncidenciaInfraestructura;
                    incidenciaInfraestructura.IdIncidencia = viewModel.IdIncidencia;
                    incidenciaInfraestructura.FechaIncidencia = viewModel.FechaIncidencia;
                }

                var result = _incidenciasInfraestructuraService.ModificarIncidenciaInfraestructura(incidenciaInfraestructura);

                if (result.Failure)
                {
                    return JsonBadRequest(result.Message());
                }
                return JsonOk(new { responseText = Resource.DatosGuardadosCorrectamente });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        [HttpPost]
        [AjaxOnly]
        public JsonResult EliminarIncidenciaInfraestructura(int id)
        {
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                var result = _incidenciasInfraestructuraService.EliminarIncidenciaInfraestructura(id);
                if (result.Failure)
                {
                    return JsonBadRequest(result.Message());
                }

                return JsonOk(new { responseText = Resource.DatosEliminadosCorrectamente });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        [HttpPost]
        public ActionResult ActualizarManga(MangasViewModelEdit mangasViewModel)
        {
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {

                var manga = new Manga()
                {
                    IdManga = mangasViewModel.IdManga,
                    Paraje = mangasViewModel.Paraje,
                    UtmX = mangasViewModel.UtmX,
                    UtmY = mangasViewModel.UtmY,
                    Anio = mangasViewModel.Anio,
                    Dimension = mangasViewModel.Dimension,
                    IdMaterialCierre = mangasViewModel.SelectedMaterialCierre,
                    IdMaterialPortillo = mangasViewModel.SelectedMaterialPortillo,
                    NumeroPortillos = mangasViewModel.NumeroPortillos,
                    AtrapaderaGanadoMayor = mangasViewModel.AtrapaderaGanadoMayor,
                    AtrapaderaGanadoMenor = mangasViewModel.AtrapaderaGanadoMenor,
                    FuncionamientoCorrectoPortillos = mangasViewModel.FuncionamientoCorrectoPortillos,
                    SoleraPasillo = mangasViewModel.SoleraPasillo,
                    DimensionSolera = mangasViewModel.DimensionSolera,
                    IdEstadoConservacion = mangasViewModel.SelectedEstadoConservacion,
                    IdEstadoAcceso = mangasViewModel.SelectedEstadoAcceso,
                    IdEntorno = mangasViewModel.SelectedEntorno,
                    Observaciones = mangasViewModel.Observaciones,
                    FechaUltimaInspeccion = mangasViewModel.FechaUltimaInspeccion
                };

                _mangasService.ModificarManga(manga);

                var url = Url.Action("FichaManga", new { idManga = mangasViewModel.IdManga }).ToString();
                return Content(url);
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }


        }

        public ActionResult ImagenesManga(int idElemento)
        {
            if (UserManager.TieneRol(Filtros.Administrador) || UserManager.TieneRol(Filtros.Consultor) || UserManager.EsUsuarioInternet)
            {
                var imagenesManga = _infraestructurasService.GetImagenesByIdElemento(idElemento, (int)TipoDocumentoEnum.Imagenes, (int)InfraestructuraEnum.Manga);


                var listaImagenes = imagenesManga.Success
                 ? _mapper.Map<List<DocumentosInfraestructurasViewModel>>(imagenesManga.GetValue())
                 : new List<DocumentosInfraestructurasViewModel>();


                var viewModel = new MangasViewModel();
                viewModel.IdManga= idElemento;
                viewModel.Imagenes = listaImagenes;

                return View("ImagenesManga", viewModel);

            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }


        }

        [HttpPost]
        public ActionResult SubirImagenCorrectoPostManga(int idElemento)
        {
            if (UserManager.TieneRol(Filtros.Administrador))
            {
                var ficherosSubidosResult = FileInputUtils.ObtenerFicherosRequest();
                if (ficherosSubidosResult)
                {
                    // Se obtienen los archivos subidos en formato HttpPostedFile
                    // en este caso tan sólo nos quedamos con el primero.
                    var datosImagen = ficherosSubidosResult.GetValue().First();


                    var fechaHoraActual = DateTime.Now;
                    var nombreMod = "man_" + fechaHoraActual.Day + fechaHoraActual.Month + fechaHoraActual.Year + fechaHoraActual.Hour + fechaHoraActual.Minute + fechaHoraActual.Second + "_" + datosImagen.GetFileName();


                    // Se insertan en el webservice.
                    var subidaFicheroResult = _subidaBajadaFicherosService.InsDocumentoGenerico(new DocumentoGenerico
                    {
                        Nombre = nombreMod,
                        Contenido = datosImagen.ToByteArray()
                    });


                    if (subidaFicheroResult)
                    {

                        //guardamos nombre en bd
                        var subido = _infraestructurasService.SubirArchivo(datosImagen.GetFileName(), nombreMod, (int)InfraestructuraEnum.Manga, (int)TipoDocumentoEnum.Imagenes, idElemento);

                        if (subido)
                        {
                            AniadirMensaje(new MensajeVm
                            {
                                Titulo = "Subida correcta",
                                Mensaje = "Se ha subido correctamente el archivo!",
                                TipoMensaje = TipoMensaje.Correcto,
                                Ocultable = true
                            });
                        }
                        else
                        {
                            _subidaBajadaFicherosService.EliminarDocumento(datosImagen.GetFileName());

                            AniadirMensaje(new MensajeVm
                            {
                                Titulo = "Error de subida",
                                Mensaje = "Ha habido un error al subir el archivo!",
                                TipoMensaje = TipoMensaje.Error,
                                Ocultable = true
                            });
                        }

                    }
                    else
                    {
                        AniadirMensaje(new MensajeVm
                        {
                            Titulo = "Error de subida",
                            Mensaje = "Ha habido un error al subir el archivo!",
                            TipoMensaje = TipoMensaje.Error,
                            Ocultable = true
                        });
                    }
                }
                else
                {
                    AniadirMensaje(new MensajeVm
                    {
                        Titulo = "Error de subida",
                        Mensaje = "Ha habido un error al subir el archivo!",
                        TipoMensaje = TipoMensaje.Error,
                        Ocultable = true
                    });
                }
                //return RedirectToAction("index");
                return RedirectToAction("ImagenesManga", new { @idElemento= idElemento });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        public ActionResult DescargarImagenManga(int idDocumentoInfraestructura)
        {
            if (UserManager.TieneRol(Filtros.Administrador) || UserManager.TieneRol(Filtros.Consultor) || UserManager.EsUsuarioInternet)
            {
                var imagen = _infraestructurasService.GetImagenByIdDocumentoInfraestructura(idDocumentoInfraestructura);
                var documentoGenerico = _subidaBajadaFicherosService.GetDocumentoGenerico(imagen.GetValue().ArchivoMod);


                return File(documentoGenerico.Contenido, System.Net.Mime.MediaTypeNames.Application.Octet, imagen.GetValue().Archivo);



            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }


        }

        public ActionResult EliminarImagenManga(int idDocumentoInfraestructura)
        {
            if (UserManager.TieneRol(Filtros.Administrador))
            {
                // Se elimina del webservice.
                var archivo = _infraestructurasService.GetImagenByIdDocumentoInfraestructura(idDocumentoInfraestructura);
                var deleteFicheroResult = _subidaBajadaFicherosService.EliminarDocumento(archivo.GetValue().ArchivoMod);


                if (deleteFicheroResult)
                {

                    //eliminamos de bd
                    var eliminado = _infraestructurasService.EliminarDocumento(idDocumentoInfraestructura);

                    if (eliminado)
                    {
                        AniadirMensaje(new MensajeVm
                        {
                            Titulo = "Eliminación correcta",
                            Mensaje = "Se ha eliminado correctamente el archivo!",
                            TipoMensaje = TipoMensaje.Correcto,
                            Ocultable = true
                        });
                    }
                    else
                    {
                        AniadirMensaje(new MensajeVm
                        {
                            Titulo = "Error de eliminación",
                            Mensaje = "Ha habido un error al eliminar el archivo!",
                            TipoMensaje = TipoMensaje.Error,
                            Ocultable = true
                        });
                    }

                }
                else
                {
                    AniadirMensaje(new MensajeVm
                    {
                        Titulo = "Error de eliminación",
                        Mensaje = "Ha habido un error al eliminar el archivo!",
                        TipoMensaje = TipoMensaje.Error,
                        Ocultable = true
                    });
                }

                //return RedirectToAction("index");
                return RedirectToAction("ImagenesManga", new { @idElemento = archivo.GetValue().IdElemento });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }

        }

        public ActionResult VerImagenManga(int idDocumentoInfraestructura)
        {

            if (UserManager.TieneRol(Filtros.Administrador) || UserManager.TieneRol(Filtros.Consultor) || UserManager.EsUsuarioInternet)
            {
                var imagen = _infraestructurasService.GetImagenByIdDocumentoInfraestructura(idDocumentoInfraestructura);
                var documentoGenerico = _subidaBajadaFicherosService.GetDocumentoGenerico(imagen.GetValue().ArchivoMod);

                return Json(documentoGenerico.Contenido.ToImagenBase64(), JsonRequestBehavior.AllowGet);


            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }


        }

        #region Incidencias
        public ActionResult ArchivosIncidenciaInfraestructura(int idIncidenciaInfraestructura, int idManga)
        {
            if (UserManager.TieneRol(Filtros.Administrador) || UserManager.TieneRol(Filtros.Consultor) || UserManager.EsUsuarioInternet)
            {
                var incidenciasArchivos = _incidenciasInfraestructuraService.GetDocumentosIncidenciasInfraestructuraByIdIncid(idIncidenciaInfraestructura);



                var listaArchivos = incidenciasArchivos.Success
                 ? _mapper.Map<List<DocumentosIncidenciaInfraestructuraViewModel>>(incidenciasArchivos.GetValue())
                 : new List<DocumentosIncidenciaInfraestructuraViewModel>();


                var viewModel = new IncidenciaInfraestructuraViewModel();
                viewModel.IdIncidenciaInfraestructura= idIncidenciaInfraestructura;
                viewModel.Archivos = listaArchivos;
                viewModel.IdElemento = idManga;

                return View("DocumentosIncidencia", viewModel);
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        public ActionResult DescargarDocumentoIncidenciaInfraestructura(int idIncidenciaInfraestructura)
        {
            if (UserManager.TieneRol(Filtros.Administrador) || UserManager.TieneRol(Filtros.Consultor) || UserManager.EsUsuarioInternet)
            {
                var archivo = _incidenciasInfraestructuraService.GetDocumentoIncidenciaInfraestructuraById(idIncidenciaInfraestructura);
                var documentoGenerico = _subidaBajadaFicherosService.GetDocumentoGenerico(archivo.GetValue().ArchivoMod);

                return File(documentoGenerico.Contenido, System.Net.Mime.MediaTypeNames.Application.Octet, archivo.GetValue().Archivo);
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        public ActionResult EliminarDocumentoIncidenciaInfraestructura(int idIncidenciaInfraestructura, int idManga)
        {
            if (UserManager.TieneRol(Filtros.Administrador) && !UserManager.EsUsuarioInternet)
            {
                // Se elimina del webservice.
                var archivo = _incidenciasInfraestructuraService.GetDocumentoIncidenciaInfraestructuraById(idIncidenciaInfraestructura);
                var deleteFicheroResult = _subidaBajadaFicherosService.EliminarDocumento(archivo.GetValue().ArchivoMod);


                if (deleteFicheroResult)
                {
                    //eliminamos de bd
                    var eliminado = _incidenciasInfraestructuraService.EliminarDocumentoIncidenciaInfraestructura(idIncidenciaInfraestructura);

                    if (eliminado)
                    {
                        AniadirMensaje(new MensajeVm
                        {
                            Titulo = "Eliminación correcta",
                            Mensaje = "Se ha eliminado correctamente el archivo!",
                            TipoMensaje = TipoMensaje.Correcto,
                            Ocultable = true
                        });
                    }
                    else
                    {
                        AniadirMensaje(new MensajeVm
                        {
                            Titulo = "Error de eliminación",
                            Mensaje = "Ha habido un error al eliminar el archivo!",
                            TipoMensaje = TipoMensaje.Error,
                            Ocultable = true
                        });
                    }
                }
                else
                {
                    AniadirMensaje(new MensajeVm
                    {
                        Titulo = "Error de eliminación",
                        Mensaje = "Ha habido un error al eliminar el archivo!",
                        TipoMensaje = TipoMensaje.Error,
                        Ocultable = true
                    });
                }

                return RedirectToAction("ArchivosIncidenciaInfraestructura", new { @idIncidenciaInfraestructura = archivo.GetValue().IdIncidenciaInfraestructura, @idManga = idManga });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }

        [HttpPost]
        public ActionResult SubirDocumentoIncidecniaInfraestructura(int idIncidenciaInfraestructura, int idManga)
        {
            if (UserManager.TieneRol(Filtros.Administrador))
            {
                var ficherosSubidosResult = FileInputUtils.ObtenerFicherosRequest();
                if (ficherosSubidosResult)
                {
                    // Se obtienen los archivos subidos en formato HttpPostedFile
                    // en este caso tan sólo nos quedamos con el primero.
                    var datosImagen = ficherosSubidosResult.GetValue().First();

                    var fechaHoraActual = DateTime.Now;
                    var nombreMod = "incid_" + fechaHoraActual.Day + fechaHoraActual.Month + fechaHoraActual.Year + fechaHoraActual.Hour + fechaHoraActual.Minute + fechaHoraActual.Second + "_" + datosImagen.GetFileName();


                    // Se insertan en el webservice.
                    var subidaFicheroResult = _subidaBajadaFicherosService.InsDocumentoGenerico(new DocumentoGenerico
                    {
                        Nombre = nombreMod,
                        Contenido = datosImagen.ToByteArray()
                    });


                    if (subidaFicheroResult)
                    {
                        //guardamos nombre en bd
                        var subido = _incidenciasInfraestructuraService.SubirDocumentoIncidenciaInfraestructura(datosImagen.GetFileName(), nombreMod, idIncidenciaInfraestructura);


                        if (subido)
                        {
                            AniadirMensaje(new MensajeVm
                            {
                                Titulo = "Subida correcta",
                                Mensaje = "Se ha subido correctamente el archivo!",
                                TipoMensaje = TipoMensaje.Correcto,
                                Ocultable = true
                            });
                        }
                        else
                        {
                            _subidaBajadaFicherosService.EliminarDocumento(datosImagen.GetFileName());

                            AniadirMensaje(new MensajeVm
                            {
                                Titulo = "Error de subida",
                                Mensaje = "Ha habido un error al subir el archivo!",
                                TipoMensaje = TipoMensaje.Error,
                                Ocultable = true
                            });
                        }

                    }
                    else
                    {
                        AniadirMensaje(new MensajeVm
                        {
                            Titulo = "Error de subida",
                            Mensaje = "Ha habido un error al subir el archivo!",
                            TipoMensaje = TipoMensaje.Error,
                            Ocultable = true
                        });
                    }
                }
                else
                {
                    AniadirMensaje(new MensajeVm
                    {
                        Titulo = "Error de subida",
                        Mensaje = "Ha habido un error al subir el archivo!",
                        TipoMensaje = TipoMensaje.Error,
                        Ocultable = true
                    });
                }
                return RedirectToAction("ArchivosIncidenciaInfraestructura", new { @idIncidenciaInfraestructura = idIncidenciaInfraestructura, @idManga = idManga });
            }
            else
            {
                return JsonBadRequest(Resource.MsgErrorMensajeAccesoDenegado);
            }
        }
        #endregion

    }
}