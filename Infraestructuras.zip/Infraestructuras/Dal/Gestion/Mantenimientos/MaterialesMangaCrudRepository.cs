﻿
using MontesPatrimoniales.Dal.Interfaces.Gestion.Mantenimientos;
using MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Impl;
using MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Interfaces;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using Ssid.Arquitectura.DBManager.Interfaces;
using System.Collections.Generic;

namespace MontesPatrimoniales.Dal.Gestion.Mantenimientos
{
    public class MaterialesMangaCrudRepository : IMaterialesMangaCrudRepository
    {
        private const string GET_MATERIALES = "Get_MaterialesManga";
        private readonly IDataBaseManager _dataBaseManager;
        private readonly IMaterialMangaMapper _materialMapper;
        
        public MaterialesMangaCrudRepository(IDataBaseManager dataBaseManager, IMaterialMangaMapper materialMapper)
        {
            _dataBaseManager = dataBaseManager;
            _materialMapper = materialMapper;
        }

        public List<MaterialManga> GetMaterialesManga()
        {
            var materiales= new List<MaterialManga>();
            var command = _dataBaseManager.GetStoredProcedureCommand(GET_MATERIALES);
            using (var dataReader = _dataBaseManager.ExecuteReader(command))
            {
                while (dataReader.Read())
                {
                    var elemento = _materialMapper.Map(dataReader);
                    materiales.Add(elemento);
                }
            }
            return materiales;
        }

    }
}
