﻿using MontesPatrimoniales.Dal.Interfaces.Gestion.Mantenimientos;
using MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Interfaces;
using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using Ssid.Arquitectura.DBManager.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace MontesPatrimoniales.Dal.Gestion.Mantenimientos
{
    public class MangasCrudRepository : IMangasCrudRepository
    {
        private const string INS_MANGA = "Ins_Manga";
        private const string UPD_MANGA = "Upd_Manga";
        private const string DEL_MANGA = "Del_Manga";
        private const string GET_MANGA_BY_ID = "Get_Manga_By_Id";
        private const string GET_MANGAS_FILTERED = "Get_Mangas_Filtered";

        private readonly IDataBaseManager _dataBaseManager;
        private readonly IMangaMapper _mapper;

        public MangasCrudRepository(IDataBaseManager dataBaseManager, IMangaMapper mapper)
        {
            _dataBaseManager = dataBaseManager;
            _mapper = mapper;
        }

        public bool AltaManga(Manga manga)
        {
            int affectedRows = 0;

            using (var scope = new TransactionScope())
            {
                var command = _dataBaseManager.GetStoredProcedureCommand(INS_MANGA);

                _dataBaseManager.AddInInteger32Parameter(command, "@IdInfraestructura", manga.IdInfraestructura);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdLocalidad", manga.IdLocalidad);
                _dataBaseManager.AddInStringParameter(command, "@Codigo", manga.Codigo);
                _dataBaseManager.AddInStringParameter(command, "@Paraje", manga.Paraje);
                _dataBaseManager.AddInInteger32Parameter(command, "@UtmX", manga.UtmX);
                _dataBaseManager.AddInInteger32Parameter(command, "@UtmY", manga.UtmY);
                _dataBaseManager.AddInInteger32Parameter(command, "@Anio", manga.Anio);
                _dataBaseManager.AddInDecimalParameter(command, "@Dimension", manga.Dimension);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdMaterialCierre", manga.IdMaterialCierre);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdMaterialPortillo", manga.IdMaterialPortillo);
                _dataBaseManager.AddInStringParameter(command, "@NumeroPortillos", manga.NumeroPortillos);
                _dataBaseManager.AddInBooleanParameter(command, "@AtrapaderaGanadoMayor", manga.AtrapaderaGanadoMayor);
                _dataBaseManager.AddInBooleanParameter(command, "@AtrapaderaGanadoMenor", manga.AtrapaderaGanadoMenor);
                _dataBaseManager.AddInBooleanParameter(command, "@FuncionamientoCorrectoPortillos", manga.FuncionamientoCorrectoPortillos);
                _dataBaseManager.AddInBooleanParameter(command, "@SoleraPasillo", manga.SoleraPasillo);
                _dataBaseManager.AddInDecimalParameter(command, "@DimensionSolera", manga.DimensionSolera);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdEstadoConservacion", manga.IdEstadoConservacion);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdEntorno", manga.IdEntorno);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdEstadoAcceso", manga.IdEstadoAcceso);
                _dataBaseManager.AddInStringParameter(command, "@Observaciones", manga.Observaciones);
                _dataBaseManager.AddInDateTimeParameter(command, "@FechaUltimaInspeccion", manga.FechaUltimaInspeccion);
                _dataBaseManager.AddOutIntParameter(command, "@IdManga");

                affectedRows = _dataBaseManager.ExecuteNonQuery(command);

                manga.IdManga = (int)_dataBaseManager.GetParameterValue(command, "@IdManga");

                scope.Complete();
            }

            return manga.IdManga > 0;
        }

        public bool EliminarManga(int idManga) 
        {
            var command = _dataBaseManager.GetStoredProcedureCommand(DEL_MANGA);
            _dataBaseManager.AddInInteger32Parameter(command, "@IdManga", idManga);

            int affectedRows = _dataBaseManager.ExecuteNonQuery(command);
            return affectedRows == -1;
        }

        public Manga GetMangaById(int id)
        {
            var mangas = new List<Manga>();
            var command = _dataBaseManager.GetStoredProcedureCommand(GET_MANGA_BY_ID);
            _dataBaseManager.AddInInteger32Parameter(command, "@IdManga", id);

            using (var dataReader = _dataBaseManager.ExecuteReader(command))
            {
                while (dataReader.Read())
                {
                    var manga = _mapper.Map(dataReader);
                    mangas.Add(manga);
                }
            }
            return mangas.FirstOrDefault();
        }
        
        public bool ModificarManga(Manga manga)
        {
            int result = 0;

            using (var scope = new TransactionScope())
            {
                // Insertar datos generales chabolas
                var command = _dataBaseManager.GetStoredProcedureCommand(UPD_MANGA);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdManga", manga.IdManga);
                _dataBaseManager.AddInStringParameter(command, "@Paraje", manga.Paraje);
                _dataBaseManager.AddInInteger32Parameter(command, "@UtmX", manga.UtmX);
                _dataBaseManager.AddInInteger32Parameter(command, "@UtmY", manga.UtmY);
                _dataBaseManager.AddInInteger32Parameter(command, "@Anio", manga.Anio);
                _dataBaseManager.AddInDecimalParameter(command, "@Dimension", manga.Dimension);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdMaterialCierre", manga.IdMaterialCierre);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdMaterialPortillo", manga.IdMaterialPortillo);
                _dataBaseManager.AddInStringParameter(command, "@NumeroPortillos", manga.NumeroPortillos);
                _dataBaseManager.AddInBooleanParameter(command, "@AtrapaderaGanadoMayor", manga.AtrapaderaGanadoMayor);
                _dataBaseManager.AddInBooleanParameter(command, "@AtrapaderaGanadoMenor", manga.AtrapaderaGanadoMenor);
                _dataBaseManager.AddInBooleanParameter(command, "@FuncionamientoCorrectoPortillos", manga.FuncionamientoCorrectoPortillos);
                _dataBaseManager.AddInBooleanParameter(command, "@SoleraPasillo", manga.SoleraPasillo);
                _dataBaseManager.AddInDecimalParameter(command, "@DimensionSolera", manga.DimensionSolera);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdEstadoConservacion", manga.IdEstadoConservacion);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdEntorno", manga.IdEntorno);
                _dataBaseManager.AddInInteger32Parameter(command, "@IdEstadoAcceso", manga.IdEstadoAcceso);
                _dataBaseManager.AddInStringParameter(command, "@Observaciones", manga.Observaciones);
                _dataBaseManager.AddInDateTimeParameter(command, "@FechaUltimaInspeccion", manga.FechaUltimaInspeccion);
                _dataBaseManager.AddOutIntParameter(command, "@ROWCOUNT");

                _dataBaseManager.ExecuteNonQuery(command);

                result = (int)_dataBaseManager.GetParameterValue(command, "@ROWCOUNT");

                scope.Complete();
            }

            return result > 0;
        }

        public List<Manga> GetMangas(int? localidad, string codigoFiltro, string parajeFiltro)
        {
            var mangas = new List<Manga>();
            var command = _dataBaseManager.GetStoredProcedureCommand(GET_MANGAS_FILTERED);

            _dataBaseManager.AddInInteger32Parameter(command, "@IdLocalidad", localidad);
            _dataBaseManager.AddInStringParameter(command, "@CodigoFiltro", codigoFiltro);
            _dataBaseManager.AddInStringParameter(command, "@ParajeFiltro", parajeFiltro);

            using (var dataReader = _dataBaseManager.ExecuteReader(command))
            {
                while (dataReader.Read())
                {
                    var manga = _mapper.MapConsulta(dataReader);
                    mangas.Add(manga);
                }
            }
            return mangas;
        }
    }
}
