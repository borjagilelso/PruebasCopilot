﻿using MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Interfaces;
using MontesPatrimoniales.Dal.Extensions;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using Ssid.Arquitectura.DBManager.Util;
using System.Data;
using System.Security.Claims;

namespace MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Impl
{
    public class MangaMapper : IMangaMapper
    {
        public Manga Map(IDataReader dataReader)
        {
            return new Manga
            {
                IdManga = dataReader["IdManga"].ToStringValue().ToInt(),
                IdInfraestructura = dataReader["IdInfraestructura"].ToStringValue().ToInt(),
                IdLocalidad = dataReader["IdLocalidad"].ToStringValue().ToInt(),
                Codigo = dataReader["Codigo"].ToString(),
                Paraje = dataReader["Paraje"].ToString(),
                UtmX = dataReader["UtmX"].ToStringValue().ToInt(),
                UtmY = dataReader["UtmY"].ToStringValue().ToInt(),
                Anio = dataReader["Anio"].ToStringValue().ToInt(),
                Dimension = dataReader.GetNullableDecimal("Dimension"),
                IdMaterialCierre = dataReader.GetNullableInt("IdMaterialCierre"),
                IdMaterialPortillo = dataReader.GetNullableInt("IdMaterialPortillo"),
                NumeroPortillos = dataReader["NumeroPortillos"].ToString(),
                AtrapaderaGanadoMayor = dataReader.GetNullableBool("AtrapaderaGanadoMayor"),
                AtrapaderaGanadoMenor = dataReader.GetNullableBool("AtrapaderaGanadoMenor"),
                FuncionamientoCorrectoPortillos = dataReader.GetNullableBool("FuncionamientoCorrectoPortillos"),
                SoleraPasillo = dataReader.GetNullableBool("SoleraPasillo"),
                DimensionSolera = dataReader.GetNullableDecimal("DimensionSolera"),
                IdEstadoConservacion = dataReader.GetNullableInt("IdEstadoConservacion"),
                IdEstadoAcceso = dataReader["IdEstadoAcceso"].ToStringValue().ToInt(),
                IdEntorno = dataReader["IdEntorno"].ToStringValue().ToInt(),
                Observaciones = dataReader.GetNullableString("Observaciones"),
                FechaUltimaInspeccion = dataReader["FechaUltimaInspeccion"].ToDateTime()
            };
        }

        public Manga MapConsulta(IDataReader dataReader)
        {
            return new Manga
            {
                IdManga = dataReader["IdManga"].ToStringValue().ToInt(),
                IdLocalidad = dataReader["IdLocalidad"].ToStringValue().ToInt(),
                Codigo = dataReader["Codigo"].ToString(),
                Paraje = dataReader["Paraje"].ToString(),
                NombreLocalidad = dataReader["NombreLocalidad"].ToStringValue(),
                Utm = "(" + dataReader["UtmX"].ToStringValue() + "," + dataReader["UtmY"].ToStringValue() + ")",
                Observaciones = dataReader["Observaciones"].ToString()
            };
        }
    }
}
