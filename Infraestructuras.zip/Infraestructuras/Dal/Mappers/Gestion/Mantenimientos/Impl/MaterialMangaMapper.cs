﻿using MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Interfaces;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using Ssid.Arquitectura.DBManager.Util;
using System.Data;

namespace MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Impl
{
    public class MaterialMangaMapper : IMaterialMangaMapper
    {
        public MaterialManga Map(IDataReader dataReader)
        {
            return new MaterialManga
            {
                IdMaterial = dataReader["IdMaterial"].ToStringValue().ToInt(),
                Nombre = dataReader["Nombre"].ToString(),
            };
        }
    }
}
