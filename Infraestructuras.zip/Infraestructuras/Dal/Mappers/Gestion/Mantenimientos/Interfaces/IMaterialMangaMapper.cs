﻿using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using System.Data;

namespace MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Interfaces
{
    public interface IMaterialMangaMapper
    {
        MaterialManga Map(IDataReader dataReader);
    }
}
