﻿using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using System.Data;

namespace MontesPatrimoniales.Dal.Mappers.Gestion.Mantenimientos.Interfaces
{
    public interface IMangaMapper
    {
        Manga Map(IDataReader dataReader);
        Manga MapConsulta(IDataReader dataReader);
    }
}
