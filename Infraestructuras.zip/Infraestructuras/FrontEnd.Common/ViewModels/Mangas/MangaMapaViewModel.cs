﻿using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Mangas
{
    public class MangaMapaViewModel
    {
        public List<Manga> Mangas { get; set; } = new List<Manga>();

        public string MangaJSON
        {
            get
            {
                try
                {
                   return JsonConvert.SerializeObject(Mangas);
                }
                catch (System.Exception ex)
                {
                    return ex.Message;
                }
            }
        }
    }
}
