﻿using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Infraestructuras;
using MontesPatrimoniales.GlobalResources;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Mangas
{
    public class MangasViewModel
    {
        public int IdManga{ get; set; }

        [Display(Name = "Codigo", ResourceType = typeof(Resource))]
        public string Codigo { get; set; }

        [Display(Name = "Localizacion", ResourceType = typeof(Resource))]
        public string NombreLocalidad { get; set; }

        [Display(Name = "Localizacion", ResourceType = typeof(Resource))]
        public IList<Localidad> Localidades { get; set; }
        //[Required(ErrorMessage = "El campo localización no puede estar vacio")]
        public int SelectedLocalidad { get; set; }

        public int IdLocalidad { get; set; }


        [Display(Name = "Paraje", ResourceType = typeof(Resource))]
        public string ParajeFiltro { get; set; }

        [Display(Name = "Codigo", ResourceType = typeof(Resource))]
        public string CodigoFiltro { get; set; }

        public List<DocumentosInfraestructurasViewModel> Imagenes { get; set; } = new List<DocumentosInfraestructurasViewModel>();

        public List<Manga> Mangas { get; set; } = new List<Manga>();

    }
}
