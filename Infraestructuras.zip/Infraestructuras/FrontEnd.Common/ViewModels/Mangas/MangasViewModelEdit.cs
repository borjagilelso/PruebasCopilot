﻿using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.Validation;
using MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Infraestructuras;
using MontesPatrimoniales.GlobalResources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MontesPatrimoniales.FrontEnd.Common.Infrastructure.MontesPatrimoniales.ViewModels.Mangas
{
    public class MangasViewModelEdit
    {
        public int IdManga{ get; set; }

        [Display(Name = "Infraestructura", ResourceType = typeof(Resource))]
        public IList<Infraestructura> Infraestructuras { get; set; }
        [Required(ErrorMessage = "El campo infraestructura no puede estar vacio")]
        public int SelectedInfraestructura { get; set; }
        public string CodigoInfraestructura { get; set; }
        public int IdInfraestructura { get; set; }

        [Display(Name = "Localizacion", ResourceType = typeof(Resource))]
        public IList<Localidad> Localidades { get; set; }
        [Required(ErrorMessage = "El campo localización no puede estar vacio")]
        public int SelectedLocalidad { get; set; }
        public string CodigoLocalidad{ get; set; }
        public int IdLocalidad { get; set; }

        [Required(ErrorMessage = "El campo codigo no puede estar vacio")]
        [StartsWith(nameof(CodigoInfraestructura), ErrorMessage = "El código debe comenzar por el prefijo")]
        [Display(Name = "Codigo", ResourceType = typeof(Resource))]
        public string Codigo { get; set; }
                
        [Required(ErrorMessage = "El campo paraje no puede estar vacio")]
        [Display(Name = "Paraje", ResourceType = typeof(Resource))]
        public string Paraje { get; set; }

        [Required(ErrorMessage = "El campo UTM (X) no puede estar vacio")]
        [Display(Name = "UTM", ResourceType = typeof(Resource))]
        [RegularExpression("^([0-9]{6})$", ErrorMessage = "Formato incorrecto (6 dígitos)")]
        public int UtmX { get; set; }

        [Required(ErrorMessage = "El campo UTM (Y) no puede estar vacio")]
        [RegularExpression("^([0-9]{7})$", ErrorMessage = "Formato incorrecto (7 dígitos)")]
        public int UtmY { get; set; }

        [Required(ErrorMessage = "El campo año no puede estar vacio")]
        [Display(Name = "Anio", ResourceType = typeof(Resource))]
        [RegularExpression("^([0-9]{4})$", ErrorMessage = "Formato incorrecto (4 dígitos)")]
        public int Anio { get; set; }

        [Range(0, 999.99, ErrorMessage = "Formato incorrecto (5 dígitos y 2 decimales)")]
        [Display(Name = "Dimension", ResourceType = typeof(Resource))]
        public decimal? Dimension { get; set; }

        [Display(Name = "MaterialCierre", ResourceType = typeof(Resource))]
        public IList<MaterialManga> MaterialesCierre { get; set; }
        public int? SelectedMaterialCierre { get; set; }
        public int? IdMaterialCierre { get; set; }

        [Display(Name = "MaterialPortillo", ResourceType = typeof(Resource))]
        public IList<MaterialManga> MaterialesPortillo { get; set; }
        public int? SelectedMaterialPortillo { get; set; }
        public int? IdMaterialPortillo { get; set; }

        [Display(Name = "NumeroPortillos", ResourceType = typeof(Resource))]
        public string NumeroPortillos { get; set; }

        [Display(Name = "AtrapaderaGanadoMayor", ResourceType = typeof(Resource))]
        public bool AtrapaderaGanadoMayor { get; set; }

        [Display(Name = "AtrapaderaGanadoMenor", ResourceType = typeof(Resource))]
        public bool AtrapaderaGanadoMenor { get; set; }

        [Display(Name = "FuncionamientoCorrectoPortillos", ResourceType = typeof(Resource))]
        public bool FuncionamientoCorrectoPortillos { get; set; }

        [Display(Name = "SoleraPasillo", ResourceType = typeof(Resource))]
        public bool SoleraPasillo { get; set; }

        [Range(0, 999.99, ErrorMessage = "Formato incorrecto (5 dígitos y 2 decimales)")]
        [Display(Name = "DimensionSolera", ResourceType = typeof(Resource))]
        public decimal? DimensionSolera { get; set; }
        
        [Display(Name = "EstadoConservacion", ResourceType = typeof(Resource))]
        public IList<Estado> EstadosConservacion { get; set; }
        public int? SelectedEstadoConservacion { get; set; }
        public int? IdEstadoConservacion { get; set; }

        [Display(Name = "EstadoAcceso", ResourceType = typeof(Resource))]
        public IList<Estado> EstadosAcceso { get; set; }
        [Required(ErrorMessage = "El campo estado de acceso no puede estar vacio")]
        public int SelectedEstadoAcceso { get; set; }
        public int IdEstadoAcceso { get; set; }

        [Display(Name = "Entorno", ResourceType = typeof(Resource))]
        public IList<Entorno> Entornos { get; set; }
        [Required(ErrorMessage = "El campo entorno no puede estar vacio")]
        public int SelectedEntorno { get; set; }
        public int IdEntorno { get; set; }

        [DataType(DataType.MultilineText), Display(Name = "Observaciones", ResourceType = typeof(Resource))]
        public string Observaciones { get; set; }

        [Required(ErrorMessage = "El campo fecha de ultima inspección no puede estar vacio")]
        [Display(Name = "FechaUltimaInspeccion", ResourceType = typeof(Resource))]
        public DateTime FechaUltimaInspeccion { get; set; }

        public List<IncidenciaInfraestructuraViewModel> Incidencias { get; set; } = new List<IncidenciaInfraestructuraViewModel>();
    }
}
