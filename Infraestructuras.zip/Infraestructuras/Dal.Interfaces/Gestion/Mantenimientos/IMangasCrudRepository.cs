﻿using MontesPatrimoniales.Entities;
using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using System.Collections.Generic;

namespace MontesPatrimoniales.Dal.Interfaces.Gestion.Mantenimientos
{
    public interface IMangasCrudRepository
    {
        bool AltaManga(Manga manga);
        Manga GetMangaById(int idManga);
        bool ModificarManga(Manga manga);
        bool EliminarManga(int idManga);
        List<Manga> GetMangas(int? localidad, string claveFiltro, string parajeFiltro);
    }
}
