﻿using MontesPatrimoniales.Entities.Gestion.Mantenimientos;
using System.Collections.Generic;

namespace MontesPatrimoniales.Dal.Interfaces.Gestion.Mantenimientos
{
    public interface IMaterialesMangaCrudRepository
    {
        List<MaterialManga> GetMaterialesManga();
    }
}
